
from flask import Flask, render_template, request, jsonify
import sqlite3

app = Flask(__name__)

def query_db(query):
    conn = sqlite3.connect('database.db')
    cur = conn.cursor()
    cur.execute(query)
    result = cur.fetchall()
    conn.close()
    return result

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    user_message = request.form['message'].lower()
    
    if "admission" in user_message:
        response = query_db("SELECT answer FROM faq WHERE question='admission'")
    elif "courses" in user_message:
        response = query_db("SELECT answer FROM faq WHERE question='courses'")
    else:
        response = [("Sorry, I don't understand. Please ask something else.",)]
    
    return jsonify(response=response[0][0])

if __name__ == "__main__":
    app.run(debug=True)
