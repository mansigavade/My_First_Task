import sqlite3

# Connect to the database (or create it if it doesn't exist)
conn = sqlite3.connect('database.db')
cur = conn.cursor()

# Create the FAQ table if it doesn't exist
cur.execute('''
CREATE TABLE IF NOT EXISTS faq (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT,
    answer TEXT
)
''')

# Insert initial data into the table
cur.execute("INSERT INTO faq (question, answer) VALUES ('admission', 'The admission process is as follows...')")
cur.execute("INSERT INTO faq (question, answer) VALUES ('courses', 'We offer a variety of courses including...')")

# Commit the transaction and close the connection
conn.commit()
conn.close()

print("Database initialized with initial data.")
